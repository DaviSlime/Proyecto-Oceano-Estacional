const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const osc = require('osc');
const os = require('os'); // Sirve para buscar tu IP
const qrcode = require('qrcode-terminal'); // Sirve para dibujar el QR

// Configuramos la conexión OSC para mandar mensajes a TouchDesigner
const udpPort = new osc.UDPPort({
    localAddress: "0.0.0.0",
    localPort: 57121, 
    metadata: true
});
udpPort.open();

// Escuchamos los puntajes que vienen de TouchDesigner
udpPort.on("message", function (oscMsg) {
    // TouchDesigner manda los nombres de tus canales así: "/primavera"
    // Le quitamos el "/" para que quede solo el nombre limpio
    let nombreEstacion = oscMsg.address.replace('/', '');
    let cantidadVotos = oscMsg.args[0].value;
    
    // Le enviamos el marcador actualizado a la página web
    io.emit('actualizarMarcador', { estacion: nombreEstacion, votos: cantidadVotos });
});

app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('✨ ¡Alguien nuevo se conectó a la votación desde su celu!');

    socket.on('votarEstacion', (estacionIndex) => {
        console.log('Voto recibido para la estación:', estacionIndex);
        udpPort.send({
            address: "/oceano/estacion",
            args: [{ type: "i", value: estacionIndex }]
        }, "127.0.0.1", 10000); 
    });

    socket.on('generarParticulas', () => {
        console.log('¡Generando partículas!');
        udpPort.send({
            address: "/oceano/particulas",
            args: [{ type: "s", value: "P" }] 
        }, "127.0.0.1", 10000);
    });
});

// Función mágica para descubrir la IP de tu compu en el Wi-Fi de la U
function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            // Buscamos la IP que no sea la interna (127.0.0.1)
            if (iface.family === 'IPv4' && !iface.internal) {
                return iface.address;
            }
        }
    }
    return 'localhost';
}

const PORT = 3000;
const localIP = getLocalIP();
const urlToShare = `http://${localIP}:${PORT}`;

// Al usar '0.0.0.0' permitimos que celulares externos entren a la página
http.listen(PORT, '0.0.0.0', () => {
    console.log('\n🌸 ¡Servidor de Dianita corriendo! 🌸');
    console.log(`Para pruebas en tu compu: http://localhost:${PORT}`);
    console.log(`Link para la gente del Wi-Fi: ${urlToShare}\n`);
    
    console.log('✨ O diles que escaneen este QR con su celu: ✨\n');
    // Generamos el QR chiquito para que quepa bien en la terminal
    qrcode.generate(urlToShare, { small: true }); 
});